function popupOne() {
  document.getElementById("popupOne").innerHTML = "&#9989; Yes! The background and text colors need more contrast.";
  var popup = document.getElementById("popupOne");
  popup.classList.toggle("show");
}

function popupTwo() {
  document.getElementById("popupTwo").innerHTML = "&#9989; Absolutely! There should be alt text that appears when hovering the image. This is important for screen readers.";
  var popup = document.getElementById("popupTwo");
  popup.classList.toggle("show");
}

function popupThree() {
  document.getElementById("popupThree").innerHTML = "&#9989; Terrific! Links to other sites need to be descriptive and include a title of the linked page to let users with screen readers know where the link redirects.";
  var popup = document.getElementById("popupThree");
  popup.classList.toggle("show");
}

function popupFour() {
  document.getElementById("popupFour").innerHTML = "&#10060; Sorry. This text is already accessible. The color contrast passes the WCAG tests and is readable by screen reading software.";
  var popup = document.getElementById("popupFour");
  popup.classList.toggle("show");
}

function popupFive() {
  document.getElementById("popupFive").innerHTML = "&#10060; Sorry. This text is already accessible. The color contrast passes the WCAG tests and is readable by screen reading software.";
  var popup = document.getElementById("popupFive");
  popup.classList.toggle("show");
}